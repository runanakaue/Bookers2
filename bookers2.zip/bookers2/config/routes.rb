Rails.application.routes.draw do






  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :books

  post 'books' ,to: 'books#create'

  devise_for :users

  resources :users, only: [:index, :show, :edit, :update] do
    member do
      # get 'show', to: 'users#show'
    end
  end

  resources :profile_image_id, only: [:new, :create, :index, :show, :destroy]
end
