class BooksController < ApplicationController
  before_action :require_permission, only: [:edit, :update, :destroy]
  before_action :authorize_user, only: [:edit, :update]

  def index
    @books = Book.includes(:user)
    @book = Book.new
    @book_new = Book.new
    @user = current_user
  end

  def show
    @book_new = Book.new  # <%= form_with ... %>で使用する空のモデル
    @book = Book.find(params[:id])  # idで指定された bookの表示用
    @user = @book.user
  end

  def edit
    @book = Book.find(params[:id])
    @book.save
    if @book.user != current_user
      redirect_to books_path
    end
  end

  def create
    @book_new = current_user.books.new(book_params)

    # @book = Book.new(book_params)
    # @book.user = current_user
    # 上と同じ意味

    if @book_new.save
      flash[:notice] = 'Book was successfully created.'
      redirect_to book_path(@book_new.id)
    else
      @user = current_user
      @books = Book.all
      # @book_new = Book.new
      render :index
    end
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = 'Book was successfully updated.'
      redirect_to book_path(@book.id)
    else
      render :edit
    end
  end

  def destroy
    @book = Book.find(params[:id])
    if @book.destroy
      flash[:notice] = 'Book was successfully destroyed.'
      redirect_to books_path
    end
  end

  private

  def book_params
    params.require(:book).permit(:title, :body)
  end

  def require_permission
    @book = Book.find(params[:id])
    if @book.user != current_user
      redirect_to books_path, alert: "他人の投稿は編集・削除できません。"
    end
  end

  def authorize_user
    unless current_user == @book.user
      flash[:alert] = "You are not authorized to perform this action."
      redirect_to root_path
    end
  end
end
