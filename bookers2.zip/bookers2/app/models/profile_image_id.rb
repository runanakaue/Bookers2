class ProfileImageId < ApplicationRecord

  belongs_to :user


  attachment :profile_image_id
end