class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  has_many :books

  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  attachment :profile_image

  # attachment :image
  validates :name, presence: true, uniqueness: true, length: { minimum: 2, maximum: 20 }

  # validates :introduction, presence: true, length: { maximum: 50 }

  validates :introduction, length: { maximum: 50 }
end
